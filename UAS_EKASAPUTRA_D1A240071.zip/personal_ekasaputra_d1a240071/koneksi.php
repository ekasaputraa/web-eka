<?php
$host = "localhost";
$user = "root";
$password = "";
$nama_database = "db_ekasaputra_d1a240071";
$db = mysqli_connect($host, $user,$password, $nama_database);
?>